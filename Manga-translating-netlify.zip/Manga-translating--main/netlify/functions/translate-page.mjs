import { GoogleGenAI, Type } from "@google/genai";

const CACHE_TTL_MS = 6 * 60 * 60 * 1000;
const MAX_CHUNK_SIZE = 12;
const MAX_RETRIES = 4;

const cache = new Map();

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function normalizeText(text) {
  return String(text || "").replace(/\s+/g, " ").trim();
}

function cacheKey(targetLanguage, bubbles) {
  return `${targetLanguage}::${bubbles.map(normalizeText).join("\n")}`;
}

function getCached(key) {
  const hit = cache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.ts > CACHE_TTL_MS) { cache.delete(key); return null; }
  return hit.value;
}

function setCached(key, value) {
  cache.set(key, { value, ts: Date.now() });
}

function chunkArray(items, size) {
  const out = [];
  for (let i = 0; i < items.length; i += size) out.push(items.slice(i, i + size));
  return out;
}

async function retryWithBackoff(fn, maxRetries = MAX_RETRIES) {
  let lastError;
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err;
      const msg = String(err?.message || err).toLowerCase();
      const retryable =
        msg.includes("429") || msg.includes("503") || msg.includes("overloaded") ||
        msg.includes("unavailable") || msg.includes("timeout") ||
        msg.includes("rate limit") || msg.includes("quota");
      if (!retryable || attempt === maxRetries - 1) throw err;
      const delay = 1000 * Math.pow(2, attempt);
      console.log(`[Function] Retrying in ${delay}ms... (${attempt + 1}/${maxRetries})`);
      await sleep(delay);
    }
  }
  throw lastError;
}

export const handler = async (event) => {
  // CORS headers
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json",
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  try {
    const {
      base64Image, mimeType, sourceLanguage, targetLanguage,
      customPrompt, modelName, translationMemory, customApiKey
    } = JSON.parse(event.body || "{}");

    const apiKey = customApiKey || process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: "Missing GEMINI_API_KEY" }) };
    }

    const ai = new GoogleGenAI({ apiKey });
    const model = modelName || "gemini-2.5-flash-preview-05-20";

    // STEP 1: OCR
    console.log("[Function] Starting OCR...");
    const ocrPrompt = `Analyze this manga/comic page carefully. You must find and extract EVERY SINGLE piece of text on the page. This includes:
1. All main dialogue in speech bubbles.
2. Thought bubbles and narration boxes.
3. Small text outside bubbles (e.g., character side comments, background text).
4. Sound effects (SFX) and stylized text.

For EACH piece of text found:
1. Extract the original text (which is in ${sourceLanguage}).
2. Provide its bounding box as [ymin, xmin, ymax, xmax] where coordinates are normalized between 0 and 1000.

Do not skip any text. Be exhaustive. Return ONLY a valid JSON array.`;

    const ocrResponse = await retryWithBackoff(() =>
      ai.models.generateContent({
        model,
        contents: { parts: [{ inlineData: { data: base64Image, mimeType } }, { text: ocrPrompt }] },
        config: {
          systemInstruction: "You are an expert manga/comic OCR system. Extract EVERY piece of text. Be exhaustive.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                box_2d: { type: Type.ARRAY, items: { type: Type.INTEGER } },
                originalText: { type: Type.STRING },
              },
              required: ["box_2d", "originalText"],
            },
          },
        }
      })
    );

    let ocrJsonStr = ocrResponse.text?.trim() || "[]";
    const match = ocrJsonStr.match(/\[\s*\{[\s\S]*\}\s*\]/);
    if (match) ocrJsonStr = match[0];
    else ocrJsonStr = ocrJsonStr.replace(/```json/g, "").replace(/```/g, "").trim();

    let extractedBubbles = [];
    try {
      extractedBubbles = JSON.parse(ocrJsonStr);
    } catch (e) {
      console.error("[Function] OCR parse failed:", ocrJsonStr);
      throw new Error("Invalid response format from OCR.");
    }

    console.log(`[Function] OCR found ${extractedBubbles.length} bubbles.`);

    if (extractedBubbles.length === 0) {
      return {
        statusCode: 200, headers,
        body: JSON.stringify({ blocks: [], usage: { promptTokens: 0, candidatesTokens: 0, totalTokens: 0 } })
      };
    }

    // STEP 2: Translate in chunks
    const chunks = chunkArray(
      extractedBubbles.map((b, index) => ({ text: b.originalText, index })),
      MAX_CHUNK_SIZE
    );

    const finalTranslations = new Array(extractedBubbles.length).fill("");
    let totalPromptTokens = ocrResponse.usageMetadata?.promptTokenCount || 0;
    let totalCandidatesTokens = ocrResponse.usageMetadata?.candidatesTokenCount || 0;

    let memoryString = "";
    if (translationMemory && Object.keys(translationMemory).length > 0) {
      memoryString = Object.entries(translationMemory)
        .map(([orig, trans]) => `"${orig}" -> "${trans}"`).join("\n");
    }

    for (const chunk of chunks) {
      const chunkTexts = chunk.map(item => item.text);
      const key = cacheKey(targetLanguage, chunkTexts);
      let translatedChunk = getCached(key);

      if (!translatedChunk) {
        const translatePrompt = [
          `Translate the following manga speech bubbles from ${sourceLanguage} into natural ${targetLanguage}.`,
          "Keep the tone short, conversational, and faithful to the original meaning.",
          customPrompt ? `Additional Instructions: ${customPrompt}` : "",
          memoryString ? `\nTranslation Memory:\n${memoryString}` : "",
          "Return ONLY valid JSON matching the schema.",
          "",
          "Bubbles:",
          ...chunkTexts.map((text, index) => `${index}: ${normalizeText(text)}`)
        ].join("\n");

        const chunkResponse = await retryWithBackoff(() =>
          ai.models.generateContent({
            model,
            contents: translatePrompt,
            config: {
              temperature: 0.2,
              responseMimeType: "application/json",
              responseSchema: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    index: { type: Type.INTEGER },
                    translation: { type: Type.STRING },
                  },
                  required: ["index", "translation"],
                },
              },
            }
          })
        );

        totalPromptTokens += chunkResponse.usageMetadata?.promptTokenCount || 0;
        totalCandidatesTokens += chunkResponse.usageMetadata?.candidatesTokenCount || 0;

        let jsonStr = chunkResponse.text?.trim() || "[]";
        const tMatch = jsonStr.match(/\[\s*\{[\s\S]*\}\s*\]/);
        if (tMatch) jsonStr = tMatch[0];
        else jsonStr = jsonStr.replace(/```json/g, "").replace(/```/g, "").trim();

        try {
          translatedChunk = JSON.parse(jsonStr);
          setCached(key, translatedChunk);
        } catch (e) {
          console.error("[Function] Translation parse failed:", jsonStr);
          translatedChunk = [];
        }
      }

      for (const item of translatedChunk) {
        const originalIndex = chunk[item.index]?.index;
        if (typeof originalIndex === "number") {
          finalTranslations[originalIndex] = String(item.translation || "");
        }
      }
    }

    // STEP 3: Merge
    const blocks = extractedBubbles.map((b, i) => ({
      box_2d: b.box_2d,
      originalText: b.originalText,
      translatedText: finalTranslations[i] || b.originalText
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        blocks,
        usage: {
          promptTokens: totalPromptTokens,
          candidatesTokens: totalCandidatesTokens,
          totalTokens: totalPromptTokens + totalCandidatesTokens
        }
      })
    };

  } catch (err) {
    console.error("[Function] Error:", err);
    return {
      statusCode: 502,
      headers,
      body: JSON.stringify({ error: err?.message || "Failed to translate page" })
    };
  }
};
